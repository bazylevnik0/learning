# donationhouse
for Hack the Bronx 2<hr>
<br>
App is used Google keys, i'm create self keys for testing and can send you for testing(it is .env file) or you can generate it yourself...<br>
*prisma have great tool for monitoring database in browser
